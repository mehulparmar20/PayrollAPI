<!-- Bootstrap JS -->
<script src="{{URL::to('/')}}/public/admin/assets/js/bootstrap.bundle.min.js"></script>
	<!--plugins-->
	<script src="{{URL::to('/')}}/public/admin/assets/js/jquery.min.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
    <script src="{{URL::to('/')}}/public/admin/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/chartjs/js/chart.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/js/index.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<!--app JS-->
	<script src="{{URL::to('/')}}/public/admin/assets/js/app.js"></script>
	<!-- custome js  -->
	<script src="{{URL::to('/')}}/public/admin/custome/custome.js"></script>  
	<!-- select two  -->
	<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
	<script src="{{URL::to('/')}}/public/admin/assets/plugins/select2/js/select2-custom.js"></script>