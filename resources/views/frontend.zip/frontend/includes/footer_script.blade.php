<script src="{{URL::to('/')}}/public/frontend/assets/js/vendor/jquery-1.12.4.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/popper.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/bootstrap.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/jquery.magnific-popup.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/isotope.pkgd.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/imagesloaded.pkgd.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/jquery.counterup.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/waypoints.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/ajax-mail.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/owl.carousel.min.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/plugins.js"></script>
<script src="{{URL::to('/')}}/public/frontend/assets/js/main.js"></script>
<script src="{{URL::to('/')}}/public/frontend/custom/js/custome.js"></script>
<script src="{{URL::to('/')}}/public/frontend/custom/js/store_data.js"></script>
<script src="{{URL::to('/')}}/public/frontend/custom/js/auth.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://kit.fontawesome.com/92b650758f.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.12/dist/sweetalert2.all.min.js"></script>

<!-- select two  -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="{{URL::to('/')}}/public/admin/assets/plugins/select2/js/select2-custom.js"></script>