<p>Hello!</p>
<p>Please verify your email address to complete your Stripe account setup:</p>
<a href="{{ route('verify.stripe', ['accountId' => $stripeAccountId]) }}">Verify Email</a>
