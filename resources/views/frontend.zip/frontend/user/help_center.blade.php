@include('frontend.includes.header')
  <body>
    @include('frontend.includes.nav')
      <!-- header end -->
	  <h3>Help Center</h3>
        <!-- menu area end -->
	    @include('frontend.includes.footer')
		<!-- all js here -->
     @include('frontend.includes.footer_script')
    </body>
</html>
